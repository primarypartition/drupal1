CREATE DATABASE  IF NOT EXISTS `drupal_pro1` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `drupal_pro1`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: drupal_pro1
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `file_managed`
--

DROP TABLE IF EXISTS `file_managed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_managed` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(128) CHARACTER SET ascii NOT NULL,
  `langcode` varchar(12) CHARACTER SET ascii NOT NULL,
  `uid` int(10) unsigned DEFAULT NULL COMMENT 'The ID of the target entity.',
  `filename` varchar(255) DEFAULT NULL,
  `uri` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `filemime` varchar(255) CHARACTER SET ascii DEFAULT NULL,
  `filesize` bigint(20) unsigned DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `created` int(11) DEFAULT NULL,
  `changed` int(11) NOT NULL,
  PRIMARY KEY (`fid`),
  UNIQUE KEY `file_field__uuid__value` (`uuid`),
  KEY `file_field__uid__target_id` (`uid`),
  KEY `file_field__uri` (`uri`(191)),
  KEY `file_field__status` (`status`),
  KEY `file_field__changed` (`changed`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='The base table for file entities.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_managed`
--

LOCK TABLES `file_managed` WRITE;
/*!40000 ALTER TABLE `file_managed` DISABLE KEYS */;
INSERT INTO `file_managed` VALUES (1,'14d15d19-2e06-429b-bf38-d4a019ce6d08','en',1,'food-photographer-david-fedulov-E94j3rMcxlw-unsplash.jpg','public://2020-10/food-photographer-david-fedulov-E94j3rMcxlw-unsplash.jpg','image/jpeg',59299,1,1601866992,1601867011),(2,'0e6f37ec-8479-43b7-950f-3e62ed1c7c10','en',1,'food-photographer-david-fedulov-E94j3rMcxlw-unsplash (1).jpg','public://2020-10/food-photographer-david-fedulov-E94j3rMcxlw-unsplash (1).jpg','image/jpeg',589319,1,1601867068,1601867075),(3,'0c0f978f-28ec-4b61-b141-a8a9ab67506b','en',1,'food-photographer-david-fedulov-E94j3rMcxlw-unsplash (1)_0.jpg','public://2020-10/food-photographer-david-fedulov-E94j3rMcxlw-unsplash (1)_0.jpg','image/jpeg',589319,1,1601867210,1601867215),(4,'b910fd90-af26-4195-a6b2-8a5547143373','en',1,'gen4295.tmp.jpeg','public://2020-10/gen4295.tmp.jpeg','image/jpeg',8779,1,1602611653,1602611653),(5,'448fd40d-fd25-4a9e-bc73-0f321f4570ed','en',1,'gen563D.tmp.jpeg','public://2020-10/gen563D.tmp.jpeg','image/jpeg',7361,1,1602611653,1602611653),(6,'1f89fa68-92f6-447b-902d-7810165364fb','en',1,'gen67D2.tmp.png','public://2020-10/gen67D2.tmp.png','image/png',719,1,1602611653,1602611653),(7,'cb49385f-d145-414f-8278-ef3cbafe8d1c','en',1,'gen7272.tmp.jpg','public://2020-10/gen7272.tmp.jpg','image/jpeg',7252,1,1602611653,1602611653),(8,'23b93bd7-6b0b-4fb0-b725-a7cb0f492c70','en',1,'gen73BB.tmp.gif','public://2020-10/gen73BB.tmp.gif','image/gif',1105,1,1602611653,1602611653),(11,'1f81efb7-ed00-431c-bb91-3dfb5ab6dc4d','en',1,'aaron-burden-aRya3uMiNIA-unsplash.jpg','public://2020-10/aaron-burden-aRya3uMiNIA-unsplash.jpg','image/jpeg',1757273,1,1602627728,1602627805),(12,'df835bc6-7137-474c-b2e2-d086df8abe6e','en',1,'tom-gainor-ZqLeQDjY6fY-unsplash.jpg','public://2020-10/tom-gainor-ZqLeQDjY6fY-unsplash.jpg','image/jpeg',315192,1,1602642285,1602642290),(13,'7d8c37b8-96f6-4ded-a79f-5aaface16c92','en',1,'tom-gainor-ZqLeQDjY6fY-unsplash_0.jpg','public://2020-10/tom-gainor-ZqLeQDjY6fY-unsplash_0.jpg','image/jpeg',315192,1,1602642947,1602642952);
/*!40000 ALTER TABLE `file_managed` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-13 21:00:13
