CREATE DATABASE  IF NOT EXISTS `drupal_pro1` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `drupal_pro1`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: drupal_pro1
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `node_revision__field_image`
--

DROP TABLE IF EXISTS `node_revision__field_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `node_revision__field_image` (
  `bundle` varchar(128) CHARACTER SET ascii NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT 0 COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `langcode` varchar(32) CHARACTER SET ascii NOT NULL DEFAULT '' COMMENT 'The language code for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_image_target_id` int(10) unsigned NOT NULL COMMENT 'The ID of the file entity.',
  `field_image_alt` varchar(512) DEFAULT NULL COMMENT 'Alternative image text, for the image''s ''alt'' attribute.',
  `field_image_title` varchar(1024) DEFAULT NULL COMMENT 'Image title text, for the image''s ''title'' attribute.',
  `field_image_width` int(10) unsigned DEFAULT NULL COMMENT 'The width of the image in pixels.',
  `field_image_height` int(10) unsigned DEFAULT NULL COMMENT 'The height of the image in pixels.',
  PRIMARY KEY (`entity_id`,`revision_id`,`deleted`,`delta`,`langcode`),
  KEY `bundle` (`bundle`),
  KEY `revision_id` (`revision_id`),
  KEY `field_image_target_id` (`field_image_target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Revision archive storage for node field field_image.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `node_revision__field_image`
--

LOCK TABLES `node_revision__field_image` WRITE;
/*!40000 ALTER TABLE `node_revision__field_image` DISABLE KEYS */;
INSERT INTO `node_revision__field_image` VALUES ('article',0,4,5,'en',0,4,'In nulla pala premo qui quidne suscipere ut utrum validus.','Aliquip olim torqueo. Comis fere loquor macto secundum similis sino sit torqueo turpis.',504,380),('article',0,5,6,'en',0,5,'Aliquip amet blandit damnum iusto jus praemitto te.','Blandit damnum iaceo ibidem obruo occuro paulatim.',495,325),('article',0,6,7,'en',0,6,'At importunus patria. Causa distineo feugiat immitto ratis roto secundum sed uxor.','Antehabeo diam exputo lobortis probo.',136,346),('article',0,7,8,'en',0,7,'Abdo commoveo cui facilisi mos pneum sudo tego ullamcorper valde.','Abico adipiscing bene ibidem luctus pala.',296,573),('article',0,8,9,'en',0,8,'Exputo lucidus nibh saepius vel.','Duis facilisi feugiat ille in letalis sed.',297,108),('page',0,9,10,'en',0,11,'Donec vel ligula varius, facilisis lacus id,','',4592,3448),('page',0,9,11,'en',0,11,'Donec vel ligula varius, facilisis lacus id,','',4592,3448),('page',0,9,12,'en',0,11,'Donec vel ligula varius, facilisis lacus id,','',4592,3448),('page',0,9,13,'en',0,11,'Donec vel ligula varius, facilisis lacus id,','',4592,3448),('page',0,9,14,'en',0,11,'Donec vel ligula varius, facilisis lacus id,','',4592,3448),('page',0,9,15,'en',0,11,'Donec vel ligula varius, facilisis lacus id,','',4592,3448),('page',0,9,16,'en',0,11,'Donec vel ligula varius, facilisis lacus id,','',4592,3448);
/*!40000 ALTER TABLE `node_revision__field_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-13 21:00:31
