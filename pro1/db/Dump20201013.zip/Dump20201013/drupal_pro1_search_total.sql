CREATE DATABASE  IF NOT EXISTS `drupal_pro1` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `drupal_pro1`;
-- MySQL dump 10.16  Distrib 10.1.37-MariaDB, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: drupal_pro1
-- ------------------------------------------------------
-- Server version	10.4.14-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `search_total`
--

DROP TABLE IF EXISTS `search_total`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_total` (
  `word` varchar(50) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique word in the search index.',
  `count` float DEFAULT NULL COMMENT 'The count of the word in the index using Zipf''s law to equalize the probability distribution.',
  PRIMARY KEY (`word`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Stores search totals for words.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_total`
--

LOCK TABLES `search_total` WRITE;
/*!40000 ALTER TABLE `search_total` DISABLE KEYS */;
INSERT INTO `search_total` VALUES ('10072020',0.221586),('10092020',0.30103),('10112020',0.30103),('10132020',0.134502),('1136',0.30103),('1141',0.30103),('1358',0.30103),('1621',0.30103),('1936',0.30103),('31',0.30103),('823',0.30103),('abbas',0.0351991),('abdo',0.0517633),('abico',0.0419903),('abigo',0.0338296),('abluo',0.0401612),('accumsan',0.0305642),('acsi',0.0489913),('adipiscing',0.0263289),('admin',0.108691),('aenean',0.176091),('aliquam',0.0255075),('aliquip',0.0374421),('amet',0.0372056),('anonymous',0.158308),('antehabeo',0.0500665),('appellatio',0.0110426),('aptent',0.0223422),('arcu',0.124939),('auctor',0.30103),('augue',0.0429223),('autem',0.0338501),('bene',0.0328254),('blandit',0.0299575),('brevitas',0.030734),('caecus',0.0518424),('camur',0.0312327),('capto',0.0347243),('causa',0.0317465),('cogo',0.0326206),('comis',0.0458361),('commodo',0.0399952),('commoveo',0.036519),('condimentum',0.30103),('consectetuer',0.0338937),('consequat',0.03857),('conventio',0.0382802),('cui',0.0399124),('curabitur',0.01524),('damnum',0.0311312),('dapibus',0.0347621),('decet',0.0289797),('defui',0.0283475),('diam',0.0329238),('dignissim',0.0298962),('distineo',0.0265371),('dolor',0.0455634),('dolore',0.0379288),('dolus',0.029693),('donec',0.0147233),('duis',0.0308375),('eleifend',0.0147233),('elementum',0.30103),('eligo',0.0069387),('elit',0.0462984),('enim',0.0352441),('erat',0.00990329),('eros',0.0376166),('esca',0.0441789),('esse',0.023427),('est',0.0321847),('euismod',0.0326035),('eum',0.0367417),('exerci',0.0476418),('exputo',0.0113184),('facilisi',0.035472),('facilisis',0.0122322),('fere',0.0446775),('feugiat',0.0433973),('finibus',0.30103),('fri',0.30103),('fringilla',0.30103),('gemino',0.0580542),('genitus',0.0303899),('gilvus',0.0686896),('gravis',0.0452107),('haero',0.0389113),('hendrerit',0.0416221),('hivananunestenemo',0.0173786),('hos',0.0329214),('huic',0.0375544),('humo',0.0239122),('iaceo',0.0281764),('iaculis',0.30103),('ibidem',0.0374079),('ideo',0.022314),('ille',0.0335479),('illum',0.0531593),('immitto',0.0567424),('imperdiet',0.30103),('importunus',0.0411111),('imputo',0.0559733),('incassum',0.0449707),('inhibeo',0.0516019),('integer',0.30103),('interdico',0.0306778),('ipsum',0.176091),('iriure',0.0380911),('iusto',0.0426866),('iustum',0.0434089),('jugis',0.0532979),('jumentum',0.0529034),('jus',0.0350558),('justo',0.30103),('lacus',0.0157943),('laoreet',0.0295478),('lectus',0.30103),('lenis',0.0459006),('leo',0.176091),('letalis',0.037485),('libero',0.0321847),('ligula',0.0157943),('lobortis',0.0356665),('loquor',0.0385951),('lucidus',0.0346492),('luctus',0.0446785),('ludus',0.0220613),('luptatum',0.0305429),('macto',0.0299033),('magna',0.0348852),('massa',0.30103),('mattis',0.30103),('mauris',0.0315069),('maximus',0.30103),('melior',0.0354598),('metuo',0.0369383),('meus',0.0257645),('minim',0.0488836),('modo',0.0428035),('molior',0.0309463),('mos',0.0467242),('natu',0.0234596),('nec',0.30103),('neo',0.068611),('neque',0.0270264),('nibh',0.0494486),('nimis',0.0402805),('nisi',0.0147233),('nisl',0.0450573),('nobis',0.0331628),('non',0.0147233),('nostrud',0.0373058),('not',0.158728),('nulla',0.0575411),('nunc',0.0484724),('nutus',0.0347117),('obruo',0.0249699),('occuro',0.0329603),('odio',0.0304101),('olim',0.0563622),('oppeto',0.0519898),('orci',0.176091),('ornare',0.176091),('pagus',0.047175),('pala',0.0461393),('paratus',0.0306412),('patria',0.051568),('paulatim',0.0321415),('pecus',0.0440107),('persto',0.0512548),('pertineo',0.0482157),('plaga',0.0328916),('pneum',0.0320628),('populus',0.0265895),('porta',0.0147233),('posuere',0.30103),('praemitto',0.0410962),('praesent',0.0268509),('premo',0.0408036),('pretium',0.176091),('probo',0.0997663),('proin',0.30103),('proprius',0.0285382),('pulvinar',0.0377886),('quadrum',0.0259465),('quae',0.0659552),('qui',0.0390233),('quia',0.0318873),('quibus',0.0415835),('quidem',0.0507625),('quidne',0.0862645),('quis',0.0246532),('ratis',0.0359552),('refero',0.0317246),('refoveo',0.0380183),('rhoncus',0.176091),('roto',0.026542),('rusticus',0.0108541),('rutrum',0.176091),('saepius',0.0295274),('sagaciter',0.0302243),('sagittis',0.30103),('saluto',0.0650446),('sapien',0.30103),('scisco',0.0613131),('secundum',0.0416528),('sed',0.0128511),('semper',0.30103),('shistogimisojaprephecrethajithiclibriswacliclabrop',0.0173603),('similis',0.031128),('singularis',0.0516453),('sino',0.0315929),('sit',0.0338608),('sollicitudin',0.124939),('sudo',0.0296759),('sun',0.30103),('suscipere',0.0681466),('suscipit',0.0283691),('suspendisse',0.0347621),('tamen',0.0489363),('tation',0.0304156),('tego',0.040297),('tempor',0.30103),('tempus',0.176091),('tincidunt',0.0122063),('torqueo',0.0111629),('tortor',0.30103),('tue',0.134402),('tum',0.04088),('turpis',0.0120183),('typicus',0.0534313),('ulciscor',0.0489956),('ullamcorper',0.0286772),('ultricies',0.0347621),('usitas',0.0447712),('utinam',0.0450603),('utrum',0.0391559),('uxor',0.0327532),('valde',0.0246037),('valetudo',0.0298642),('validus',0.0373111),('varius',0.01524),('vel',0.0120648),('velit',0.0464524),('venenatis',0.30103),('veniam',0.0308028),('venio',0.0771604),('vereor',0.0460842),('verified',0.159147),('vero',0.035202),('verto',0.0508848),('vestibulum',0.30103),('vicis',0.034964),('vindico',0.0315754),('virtus',0.0510227),('vitae',0.124939),('vivamus',0.30103),('viverra',0.30103),('voco',0.0313432),('volutpat',0.0510882),('vulpes',0.0508296),('vulputate',0.025991),('wed',0.221042),('wisi',0.0424571),('wrenonutushowrewuspishiwrawrawrashudadramaswubichu',0.0172908),('wrethecrowibrakobrihawekivegohashitreguspechogoswa',0.0257108),('ymo',0.0377241),('zelus',0.0415629);
/*!40000 ALTER TABLE `search_total` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-13 21:00:24
